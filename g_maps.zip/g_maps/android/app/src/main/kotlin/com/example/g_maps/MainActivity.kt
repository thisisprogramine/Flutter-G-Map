package com.example.g_maps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
